package es.riberadeltajo.videojuegos5;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class Juego extends SurfaceView implements SurfaceHolder.Callback {

    private SurfaceHolder holder;
    private BucleJuego bucle;

    private Bitmap mapa;
    private Bitmap mario;

    private float mapa_h, mapa_w, dest_mapa_y, palla = 0;
    private float  maxY, maxX;
    private float mario_w, mario_h;

    private final int X = 0;
    private final int Y = 1;

    private float posicionMapa[] = new float[2];
    float posicionMario[] = new float[2];

   
    private static final String TAG = Juego.class.getSimpleName();

    public Juego(Activity context) {
        super(context);
        holder = getHolder();
        holder.addCallback(this);
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        // se crea la superficie, creamos el game loop
        inicializar();
    // Para interceptar los eventos de la SurfaceView
        getHolder().addCallback(this);

        // creamos el game loop
        bucle = new BucleJuego(getHolder(), this);

        // Hacer la Vista focusable para que pueda capturar eventos
        setFocusable(true);

        //comenzar el bucle
        bucle.start();

    }

    private void inicializar() {
        mapa=BitmapFactory.decodeResource(getResources(),R.drawable.mapamario);
        mapa_h=mapa.getHeight();
        mapa_w=mapa.getWidth();
        dest_mapa_y=(maxY-mapa_h)/2;

        mario = BitmapFactory.decodeResource(getResources(), R.drawable.mario);
        mario_w=mario.getWidth()/21;
        mario_h=mario.getHeight()*(2/3);

        Canvas c=holder.lockCanvas();
        maxX = c.getWidth();
        maxY = c.getHeight();
        holder.unlockCanvasAndPost(c);

        posicionMapa[X] = 0;
        posicionMapa[Y] = (maxY-mapa_h)/2;

        posicionMario[X] = 150;
        posicionMario[Y]= (float) (maxY*0.90);


    }

    /**
     * Este método actualiza el estado del juego. Contiene la lógica del videojuego
     * generando los nuevos estados y dejando listo el sistema para un repintado.
     */
    public void actualizar() {
        //palla += 5;

    }

    /**
     * Este método dibuja el siguiente paso de la animación correspondiente
     */
    public void renderizar(Canvas canvas) {
        if (canvas == null)
            return;

        //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        //hideSystemUI(); //snippet de fpribera



        canvas.drawColor(Color.BLACK);

        //pintar mensajes que nos ayudan
        Paint p=new Paint();
        p.setStyle(Paint.Style.FILL_AND_STROKE);
        p.setColor(Color.RED);
        p.setTextSize(50);



        canvas.drawText("Frame "+bucle.iteraciones+";"+"Tiempo "+bucle.tiempoTotal + " ["+bucle.maxX+","+bucle.maxY+"]",50,150,p);




        canvas.drawBitmap(mapa,
                new Rect((int) palla,0,(int)maxX+(int)palla,(int)mapa_h),
                new Rect((int)posicionMapa[X],(int)posicionMapa[Y],(int)maxX,(int)posicionMapa[Y]+(int)mapa_h),
                p);
        canvas.drawBitmap(mario,
                new Rect(0, 0, (int)mario_w, (int)mario_h),
                new Rect((int)posicionMario[X], (int) posicionMario[Y], (int)mario_w, (int)mario_h),
                p);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        Log.d(TAG, "Juego destruido!");
        // cerrar el thread y esperar que acabe
        boolean retry = true;
        while (retry) {
            try {
                bucle.join();
                retry = false;
            } catch (InterruptedException e) {

            }
        }
    }


}
